﻿namespace avaness.PluginLoader.Data
{
    public enum PluginStatus
    {
        None, PendingUpdate, Updated, Error, Blocked
    }
}
