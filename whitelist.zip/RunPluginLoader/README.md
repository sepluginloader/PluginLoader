This is the plugin that actually runs Plugin Loader. Its only job is to start 0Harmony and Plugin Loader.
