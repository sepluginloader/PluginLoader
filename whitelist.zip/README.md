# PluginLoader
A tool to load plugins for Space Engineers automatically.

To install, subscribe to the [workshop item](https://steamcommunity.com/sharedfiles/filedetails/?id=2407984968) and add `-plugin ..\..\..\workshop\content\244850\2407984968\RunPluginLoader` to the game launch options.


